/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int n, i,c;
    printf("Enter an integer: ");
    scanf("%d", &n);
    printf("Enter till where the multiplication table should be done:");
    scanf("%d", &c);
    for (i = 1; i <=c; ++i) {
        printf("%d * %d = %d \n", n, i, n * i);
    }
    return 0;
}