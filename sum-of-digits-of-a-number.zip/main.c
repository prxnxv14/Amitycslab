/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int n, r, sum=0;
	printf("enter number \n");
	scanf("%d", &n);
	while(n)
	{
		r = n%10;
		n = n/10;
		sum+=r;
	}
	printf("sum of digit is %d \n", sum);
}
